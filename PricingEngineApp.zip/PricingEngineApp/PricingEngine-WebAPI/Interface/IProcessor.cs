﻿using System.Collections.Generic;


namespace PricingEngine_WebAPI.Models
{
    public interface IProcessor//this handle task to execute the logic activator from controller to model 
    {
        void calcAveragePriceLessOrMore50(System.Collections.Generic.List<System.Collections.Generic.KeyValuePair<string, decimal>> lstComptPrice, System.Collections.Generic.List<System.Collections.Generic.KeyValuePair<string, decimal>> sumProductPrice);
        void calcMinOfMultiplePrices(System.Collections.Generic.List<System.Collections.Generic.KeyValuePair<string, decimal>> lstComptPrice);
        void competitorPriceList(ProductFilterModel objProduct, System.Collections.Generic.List<System.Collections.Generic.KeyValuePair<string, decimal>> lstComptPrice);
        List<System.Collections.Generic.KeyValuePair<string, decimal>> groupSumProductPrice(System.Collections.Generic.List<System.Collections.Generic.KeyValuePair<string, int>> lstPercentage, System.Collections.Generic.List<System.Collections.Generic.KeyValuePair<string, decimal>> lstComptPrice);
        void PercentSupplyandDemand(ProductFilterModel objProduct, System.Collections.Generic.List<System.Collections.Generic.KeyValuePair<string, int>> lstPercentage);
        List<System.Collections.Generic.KeyValuePair<string, decimal>> sumPrice(System.Collections.Generic.List<System.Collections.Generic.KeyValuePair<string, decimal>> lstComptPrice);
    }
}
