/*** All list of tables ***/
select * from [Products]
select * from [competitors] 
select * from [supply]

/*For each competitor the product price is set and api engine will calculate based on implementation logic */
/**** Update for INPUT PARAMETER OPTION 1 ****/
update competitors 
set price = 10
from competitors
where competitorname = 'X' --competitor Y
and productcode = 2--ssd

update competitors 
set price = 12.5
from competitors
where competitorname = 'Y' --Competitor Y
and productcode = 2--ssd

/***** Update for INPUT PARAMETER OPTION 2 ****/
update competitors 
set price = 12
from competitors
where competitorname = 'X' --competitor X
and productcode = 2--ssd

update competitors 
set price = 11
from competitors
where competitorname = 'Y' --Competitor Y
and productcode = 2--ssd
     