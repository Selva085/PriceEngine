﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using PricingEngine_WebAPI.Controllers;
using PricingEngine_WebAPI.Models;
using Moq;
using System.Data.Entity;
using System.Linq;

namespace PriceEngine.Tests
{
    [TestClass]
    public class PriceEngineTest
    {
        [TestMethod]
        public void GetAllProducts()
        {
            //sample test case for execution                    
            //Arrange
            var ProductEntities = new List<Product>()
            {
                 new Product()
                {
                    ProductCode = 1,
                    ProductName = "SSD",
                    Competitors = new List<Competitor>()
                    {
                        new Competitor() {CompetitorID =1,CompetitorName ="X", ProductCode=1,Price=10 }              
                   },
                    Supplies = new List<Supply>() { new Supply() { ID = 1 } }
                }
            };
            
            // Create a mock DbContext.
            var dbContext = new Mock<PricingEngineEntities>();

            // Create a mock DbSet.
            var dbSet = new Mock<DbSet<Product>>();

            // Set up the Products property so it returns the mocked DbSet.
            dbContext.Setup(x => x.Products).Returns(() => dbSet.Object);

            // Set up the DbSet as an IQueryable so it can be enumerated.
            var queryable = ProductEntities.AsQueryable();
            dbSet.As<IQueryable<Product>>().Setup(m => m.Provider).Returns(queryable.Provider);
            dbSet.As<IQueryable<Product>>().Setup(m => m.Expression).Returns(queryable.Expression);
            dbSet.As<IQueryable<Product>>().Setup(m => m.ElementType).Returns(queryable.ElementType);
            dbSet.As<IQueryable<Product>>().Setup(m => m.GetEnumerator()).Returns(() => queryable.GetEnumerator());
            
            // Act
            var controller = new ProductController(new Processor(), dbContext.Object);
            var result = controller.GetProducts();

            //Assert --Sample results
            Assert.AreEqual(ProductEntities[0].ProductCode, result.FirstOrDefault().ProductCode);
            Assert.AreEqual(ProductEntities[0].ProductName, result.FirstOrDefault().ProductName);
        }
    }
}
