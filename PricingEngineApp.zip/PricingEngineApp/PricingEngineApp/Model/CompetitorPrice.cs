﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PricingEngineApp.Model
{
    public class CompetitorPrice
    {
        public string Product { get; set; }
        public string CompetitorName { get; set; }
    }
}
