﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PricingEngineApp.Model
{
    public class ProductDemand
    {
        public string Product { get; set; }
        public string Supply { get; set; }
        public string Demand { get; set; }
    }

}
