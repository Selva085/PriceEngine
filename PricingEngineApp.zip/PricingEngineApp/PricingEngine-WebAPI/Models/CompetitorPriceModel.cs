﻿using PricingEngine_WebAPI.Interface;

namespace PricingEngine_WebAPI.Models
{
    public class CompetitorPrice : ICompetitorPrice
    {
        public string Product { get; set; }
        public string CompetitorName { get; set; }
    }
}