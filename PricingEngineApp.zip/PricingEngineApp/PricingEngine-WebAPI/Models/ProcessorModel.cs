﻿using System.Collections.Generic;
using System.Linq;

namespace PricingEngine_WebAPI.Models
{
    public class Processor : IProcessor
    {
        private PricingEngineEntities db = null;

        //Constructor to intialize the db entities object
        public Processor()
        {
            db = new PricingEngineEntities();
        }

        public List<KeyValuePair<string, decimal>> groupSumProductPrice(List<KeyValuePair<string, int>> lstPercentage, List<KeyValuePair<string, decimal>> lstComptPrice)
        {
            List<KeyValuePair<string, decimal>> grpresult = (from p in lstComptPrice
                                                             group p by p.Key
                                                                 into g
                                                                 select new KeyValuePair<string, decimal>(g.Key, g.Min(e => e.Value))
                                                       ).ToList();

            //If Supply is High and Demand is High, Product is sold at same price as chosen price.
            //If Supply is Low and Demand is Low, Product is sold at 10 % more than chosen price.
            //If Supply is Low and Demand is High, Product is sold at 5 % more than chosen price.
            //If Supply is High and Demand is Low, Product is sold at 5 % less than chosen price
            foreach (KeyValuePair<string, decimal> item in grpresult.ToList())
            {
                if (item.Key.Any())
                {
                    var perc = lstPercentage.FirstOrDefault(x => x.Key.ToLower() == item.Key.ToLower()).Value;
                    int i = grpresult.IndexOf(new KeyValuePair<string, decimal>(item.Key, item.Value));
                    KeyValuePair<string, decimal> newValue = new KeyValuePair<string, decimal>(item.Key, ((item.Value + (item.Value * perc) / 100)));
                    if (perc != 0)
                    {
                        grpresult[i] = newValue; //Calculate the new value based on supply and demand percentage of each product
                    }
                }
            }
            return grpresult;
        }

        public List<KeyValuePair<string, decimal>> sumPrice(List<KeyValuePair<string, decimal>> lstComptPrice)
        {
            List<KeyValuePair<string, decimal>> grouped = (from kvp in lstComptPrice
                                                           group kvp by kvp.Key
                                                               into g
                                                               select new KeyValuePair<string, decimal>(g.Key, g.Sum(e => e.Value))
                                                       ).ToList();
            return grouped;
        }

        public void PercentSupplyandDemand(ProductFilterModel objProduct, List<KeyValuePair<string, int>> lstPercentage)
        {
            foreach (var objProd in objProduct.ProductDemand)
            {
                if (objProd.Product.Any())
                {
                    //Calculate percentage based on Supply and Demand
                    var prodPerc = db.Products.FirstOrDefault(x => x.ProductName == objProd.Product)
                                           .Supplies.Where(y => y.Supply1.ToLower() == objProd.Supply.ToLower()
                                                     && y.Demand.ToLower() == objProd.Demand.ToLower())
                                           .Select(p => p.Percentage).FirstOrDefault();
                    //Adding product discount percentage based on supply and Demand to the dictionary collection object        
                    lstPercentage.Add(new KeyValuePair<string, int>(objProd.Product, prodPerc));
                }
            }
        }

        public void competitorPriceList(ProductFilterModel objProduct, List<KeyValuePair<string, decimal>> lstComptPrice)
        {
            foreach (var objCompPrice in objProduct.Competitor)
            {
                if (objCompPrice.CompetitorName.Any())
                {
                    var compPrice = db.Products.FirstOrDefault(x => x.ProductName == objCompPrice.Product)
                                           .Competitors.Where(y => y.CompetitorName.ToLower() == objCompPrice.CompetitorName.ToLower())
                                           .Select(p => p.Price).FirstOrDefault();
                    //Adding competitor price based on the product to the dictionary collection object                                                              
                    lstComptPrice.Add(new KeyValuePair<string, decimal>(objCompPrice.Product, compPrice));
                }
            }
        }

        public void calcMinOfMultiplePrices(List<KeyValuePair<string, decimal>> lstComptPrice)
        {
            var lstMultiplePrice = lstComptPrice
                      .GroupBy(x => new { x.Key, x.Value })
                      .Where(g => g.Count() > 1)
                      .ToList();
            foreach (var objCompPrice in lstComptPrice.ToList())
            {
                if (objCompPrice.Key.Any())
                {
                    foreach (var obj in lstMultiplePrice)
                    {
                        if (obj.Key.Key.ToLower() == objCompPrice.Key.ToLower())
                        {
                            if (!lstMultiplePrice.Any(x => x.Key.Key.ToLower() == objCompPrice.Key.ToLower() && x.Key.Value == objCompPrice.Value))
                            {
                                lstComptPrice.Remove(new KeyValuePair<string, decimal>(objCompPrice.Key, objCompPrice.Value));
                            }
                        }
                    }
                }
            }
        }

        public void calcAveragePriceLessOrMore50(List<KeyValuePair<string, decimal>> lstComptPrice, List<KeyValuePair<string, decimal>> sumProductPrice)
        {
            foreach (KeyValuePair<string, decimal> obj in sumProductPrice)
            {
                //To calculate average price for each product
                var countCalc = lstComptPrice.Where(x => x.Key == obj.Key).Count();
                var avgLess50PercPrice = (obj.Value / countCalc) - ((obj.Value / countCalc) * 50 / 100);
                var avgMore50PercPrice = (obj.Value / countCalc) + ((obj.Value / countCalc) * 50 / 100);
                var AvgPrice50Perc = lstComptPrice.Where(x => x.Key.ToLower() == obj.Key.ToLower() && (x.Value <= avgLess50PercPrice || x.Value >= avgMore50PercPrice)).FirstOrDefault();

                //Prices less than 50% of average price are treated as promotion and not considered.
                //Prices more than 50% of average price are treated as data errors and not considered.
                if (AvgPrice50Perc.Key != null && AvgPrice50Perc.Key.Any())
                {
                    lstComptPrice.Remove(new KeyValuePair<string, decimal>(AvgPrice50Perc.Key, AvgPrice50Perc.Value));
                }
            }
        }

    }
}