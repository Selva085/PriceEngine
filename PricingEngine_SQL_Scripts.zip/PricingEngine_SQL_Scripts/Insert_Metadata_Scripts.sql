
IF EXISTS(SELECT 1 FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID(N'dbo.Competitors'))
BEGIN
ALTER TABLE [dbo].[Competitors] DROP CONSTRAINT [FK_CompetitorProduct]
END
GO
IF EXISTS(SELECT 1 FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID(N'dbo.Supply'))
BEGIN
ALTER TABLE [dbo].[Supply] DROP CONSTRAINT [FK_SupplyProduct]
END
GO

truncate table [dbo].[Competitors]
truncate table [dbo].[Supply]
truncate table [dbo].[Products] 
GO
IF EXISTS(SELECT 1 FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID(N'dbo.Supply'))
BEGIN
ALTER TABLE [dbo].[Supply]  WITH CHECK ADD  CONSTRAINT [FK_SupplyProduct] FOREIGN KEY([ProductCode])
REFERENCES [dbo].[Products] ([ProductCode])
ALTER TABLE [dbo].[Supply] CHECK CONSTRAINT [FK_SupplyProduct]
END
GO
IF EXISTS(SELECT 1 FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID(N'dbo.Competitors'))
BEGIN
ALTER TABLE [dbo].[Competitors]  WITH CHECK ADD  CONSTRAINT [FK_CompetitorProduct] FOREIGN KEY([ProductCode])
REFERENCES [dbo].[Products] ([ProductCode])

ALTER TABLE [dbo].[Competitors] CHECK CONSTRAINT [FK_CompetitorProduct]
END
GO


--Metadata for Products
INSERT INTO [dbo].[Products] 
       VALUES (1,'FlashDrive'),
	          (2,'SSD'),
			  (3,'Internal Harddisk'),
			  (4,'External Desktop Harddisk'),
			  (5,'External SSD Harddisk'),
			  (6,'Mp3 Player')

--Metadata scripts for competitors which holds all competitors and pricing information of the products			  
INSERT INTO [dbo].[Competitors] 
       VALUES (1,'X',1.0),
			  (1,'Y',0.9),
			  (1,'Z',1.1),
	          (2,'X',10.0),
			  (2,'Y',12.5),
			  (2,'W',11.0),			
			  (2,'V',10.0),
			  (2,'Z',12.0),
			  (6,'X',60.0),
			  (6,'Y',20.0),
			  (6,'Z',50.0)


--Metadata scripts for competitors which holds all competitors and pricing information of the products
INSERT INTO [dbo].[Supply] 
VALUES  (1,'High','High',0),
		(1,'Low','Low',10),
		(1,'Low','High',5),
		(1,'High','Low',5),
		(2,'High','High',0),
		(2,'Low','Low',10),
		(2,'Low','High',5),
		(2,'High','Low',5),
		(6,'High','High',0),
		(6,'Low','Low',10),
		(6,'Low','High',5),
		(6,'High','Low',5)
