﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PricingEngine_WebAPI.Interface
{
    public class IProductDemand
    {
         string Product;
         string Supply;
         string Demand;
    }
}