﻿using PricingEngineApp.Model;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Text;


namespace PricingEngineApp.Controller
{
    public class PriceEngineController : PricingEngineApp.Controller.IPriceEngineController
    {
        public string callPriceEngineAPI(string strInputRequest, string strHostAddress)
        {
            var output = string.Empty;
            try
            {
                using (var client = new HttpClient())
                {
                    if (!string.IsNullOrEmpty(strHostAddress))
                    {
                        var address = strHostAddress.Substring(0, strHostAddress.IndexOf("api"));
                        client.BaseAddress = new Uri(address);// read based address if user keyed through ajax or any other client scripts.. 
                    }
                    else
                    {
                        client.BaseAddress = new Uri("http://localhost:62957/");//read from config file if user not keyed the values should be default host address.
                    }
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    ProductFilterModel model = JsonConvert.DeserializeObject<ProductFilterModel>(strInputRequest);
                    //HttpResponseMessage response1 = client.GetAsync("api/product").Result; //To get all the product information from the product table
                    var apiHttpRequestURL = strHostAddress.Substring(strHostAddress.IndexOf("api"), strHostAddress.Length - strHostAddress.IndexOf("api")); //"api/product/ProductPrice"
                    var content = new StringContent(strInputRequest, Encoding.UTF8, "text/json");
                    HttpResponseMessage response = client.PostAsync("api/product/ProductPrice", content).Result;// storing the results of posts in response
                    if (response.IsSuccessStatusCode)
                    {
                        output = response.Content.ReadAsStringAsync().Result;
                    }
                }
            }
            catch (Exception ex)
            {
                output = ex.Message.ToString() + "Inner Exception:" + ex.InnerException.ToString();
            }
            return output;
        }
    }
   
}
