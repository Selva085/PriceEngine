﻿using PricingEngineApp.Model;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Text;
using PricingEngineApp.Controller;

namespace PricingEngineApp
{
    public partial class PriceEngineClientUI : Form
    {
        private PriceEngineController objPresenter = null;//Presenter which act as a processor to execute it
        public PriceEngineClientUI()
        {
            InitializeComponent();
            objPresenter = new PriceEngineController();

        }

        private void calc_PriceClick(object sender, EventArgs e)
        {
            if (objPresenter == null)//initialize only on demand if object is not
            {
                objPresenter = new PriceEngineController();
            }
            try
            {
                txtOutput.Text = objPresenter.callPriceEngineAPI(txtInput.Text.Trim(), txthost.Text.Trim()).Replace("\\", "");
            }
            catch (Exception ex) //error handlding
            {
                txtOutput.Text = string.Format("Error has occured while processing {0}--InnerException--{1}", ex.Message.ToString(), ex.InnerException.ToString());
            }
            finally // dispose the object from memory after execution
            {
                objPresenter = null;
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtInput.Clear();
            txtOutput.Clear();
        }
    }
}
