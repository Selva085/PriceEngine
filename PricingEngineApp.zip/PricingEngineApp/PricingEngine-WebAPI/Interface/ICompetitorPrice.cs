﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PricingEngine_WebAPI.Interface
{
    public class ICompetitorPrice
    {
         string Product;
         string CompetitorName;
    }
}