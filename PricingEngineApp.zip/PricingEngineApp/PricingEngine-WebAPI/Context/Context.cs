﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PricingEngine_WebAPI.Models;


namespace PricingEngine_WebAPI.ContextInterface
{
    // The contexts class to invoke strategy interface (abstractclass)
    public class Context
    {
        private StrategyPatternSum _objStrategy;

        public Context(StrategyPatternSum objStrategy)
        {
            this._objStrategy = objStrategy;
        }

        public List<KeyValuePair<string, decimal>> contextSumPrice(List<KeyValuePair<string, decimal>> lstComptPrice)
        {
            return _objStrategy.sumPrice(lstComptPrice);
        }
    }
}