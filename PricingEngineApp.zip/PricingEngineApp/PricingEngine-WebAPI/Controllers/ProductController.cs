﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Newtonsoft.Json;
using PricingEngine_WebAPI.Models;

namespace PricingEngine_WebAPI.Controllers
{
    [RoutePrefix("api/Product")]
    public class ProductController : ApiController
    {
        private PricingEngineEntities db = null;
        private IProcessor objProcessor = null;

        //Default Constructor to intialize the db entities object
        public ProductController()
        {
            db = new PricingEngineEntities();
            objProcessor = new Processor();//assign interface to make looseluy coupled
        }

        //Parameterized Constructor to make loosely couple injection
        public ProductController(IProcessor _objProcessor, PricingEngineEntities _dbContext)
        {
            db = _dbContext;
            objProcessor = _objProcessor;//act as constructor injector based on subtypes
        }

        // GET api/Product
        [HttpGet]
        [Route("")]
        public IEnumerable<Product> GetProducts()
        {
            return db.Products;
        }

        // GET api/Product/5
        [HttpGet]
        [Route("{id}")]
        [ResponseType(typeof(Product))]
        public IHttpActionResult GetProduct(int id)
        {
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return NotFound();
            }

            return Ok(product);
        }

        // PUT api/Product/5        
        [HttpPut]
        [Route("{productName}")]
        public IHttpActionResult updateProductPrice(string productName, [FromUri]string competitorName, decimal price)
        {
            try
            {
                var productID = db.Products.FirstOrDefault(a => a.ProductName == productName.ToLower()).ProductCode;
                Competitor objCompetitor = db.Competitors.FirstOrDefault(x => x.CompetitorName == competitorName && x.ProductCode == productID);
                if (objCompetitor == null)
                {
                    return NotFound();
                }
                objCompetitor.Price = price;
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                //To be implement handle error here if any failures happen
                return StatusCode(HttpStatusCode.ExpectationFailed);
            }
            return StatusCode(HttpStatusCode.OK);
        }

        // POST api/Product
        [ResponseType(typeof(string))]
        [HttpPost]
        [Route("ProductPrice")]
        public string ProductPrice([FromBody]ProductFilterModel objProduct)
        {
            var output = Newtonsoft.Json.JsonConvert.SerializeObject(string.Empty);
            List<KeyValuePair<string, int>> lstPercentage = new List<KeyValuePair<string, int>>();
            List<KeyValuePair<string, decimal>> lstComptPrice = new List<KeyValuePair<string, decimal>>();
            try
            {
                //Process Model (objProcessor) will take responsibility to execute the calculation and other logics
                //To get percentage based on supply and demand (the caculation based on low and high value)
                objProcessor.PercentSupplyandDemand(objProduct, lstPercentage);

                //To calculate competitor prices
                objProcessor.competitorPriceList(objProduct, lstComptPrice);

                //To check multiple price value then chosen among them least value.              
                objProcessor.calcMinOfMultiplePrices(lstComptPrice);

                //Grouping all media product to sum up the value of total product for calculating average price of each product
                List<KeyValuePair<string, decimal>> sumProductPrice = objProcessor.sumPrice(lstComptPrice);

                //Each of product average price is calculated based on their sum of competitor prices 
                objProcessor.calcAveragePriceLessOrMore50(lstComptPrice, sumProductPrice);

                //Grouping all media product to sum up the value of total product for calculating average price of each product and taking least minimum price values
                List<KeyValuePair<string, decimal>> grpresult = objProcessor.groupSumProductPrice(lstPercentage, lstComptPrice);

                //output final result 
                output = JsonConvert.SerializeObject(grpresult);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                lstPercentage.Clear();
                lstComptPrice.Clear();
            }

            return output;
        }

        // DELETE api/Product/5
        [ResponseType(typeof(Product))]
        public IHttpActionResult DeleteProduct(int id)
        {
            Product product = db.Products.Find(id);
            try
            {
                if (product == null)
                {
                    return NotFound();
                }

                db.Products.Remove(product);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                //To be implement handle error here if any failures happen
                return StatusCode(HttpStatusCode.ExpectationFailed);
            }
            return Ok(product);
        }

        private bool ProductExists(int id)
        {
            return db.Products.Count(e => e.ProductCode == id) > 0;
        }
    }
}