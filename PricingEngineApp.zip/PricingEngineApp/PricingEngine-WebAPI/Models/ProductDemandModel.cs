﻿using PricingEngine_WebAPI.Interface;

namespace PricingEngine_WebAPI.Models
{
    public class ProductDemand : IProductDemand
    {
        public string Product { get; set; }
        public string Supply { get; set; }
        public string Demand { get; set; }
    }
}