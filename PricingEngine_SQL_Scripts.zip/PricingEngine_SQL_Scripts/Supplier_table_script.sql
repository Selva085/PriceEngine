USE [MDE_ARCHIVE_DEST] 
GO
--New table creation 
--This condition provided because if deployer execute this script multiple times it should not broken in production
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Supply]') AND type in (N'U'))  
DROP TABLE [dbo].[Supply]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Supply](
    [ID] [int] IDENTITY(1,1) NOT NULL, 
	[ProductCode] [int] NOT NULL,
	[Supply] [varchar](5) NOT NULL,
	[Demand] [varchar](5) not null,
	[Percentage] [int] not null
)

GO
--foreign key reference to product code competitors are binded to products master table. so that user try to avoid deletition from product table without removing any entries from supply
ALTER TABLE [dbo].[Supply]  WITH CHECK ADD  CONSTRAINT [FK_SupplyProduct] FOREIGN KEY([ProductCode])
REFERENCES [dbo].[Products] ([ProductCode])
GO

ALTER TABLE [dbo].[Supply] CHECK CONSTRAINT [FK_SupplyProduct]
GO
