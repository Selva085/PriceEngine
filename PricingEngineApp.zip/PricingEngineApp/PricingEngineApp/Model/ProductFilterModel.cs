﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PricingEngineApp.Model
{
    public class ProductFilterModel
    {
        public int NoofProduct;
        public int SurveyedPrice;
        public List<ProductDemand> ProductDemand;
        public List<CompetitorPrice> Competitor;
    }

}
