﻿using System;
namespace PricingEngineApp.Controller
{
    interface IPriceEngineController
    {
        string callPriceEngineAPI(string strInputRequest, string strHostAddress);
    }
}
