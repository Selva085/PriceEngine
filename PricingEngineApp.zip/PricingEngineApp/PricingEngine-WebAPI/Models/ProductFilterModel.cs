﻿using System.Collections.Generic;

namespace PricingEngine_WebAPI.Models
{
    public class ProductFilterModel
    {
        public int NoofProduct;
        public int SurveyedPrice;
        public List<ProductDemand> ProductDemand;
        public List<CompetitorPrice> Competitor;          
    }



  
}