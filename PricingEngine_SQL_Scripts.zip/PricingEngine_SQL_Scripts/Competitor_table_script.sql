USE [MDE_ARCHIVE_DEST] 
GO
--New table creation 
--This condition provided because if deployer execute this script multiple times it should not broken in production
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Competitors]') AND type in (N'U'))  
DROP TABLE [dbo].[Competitors]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Competitors](
    [CompetitorID] [int] IDENTITY(1,1) NOT NULL, 
	[ProductCode] [int] NOT NULL,
	[CompetitorName] [varchar](100) NOT NULL,
	[Price] [money] not null 
)

GO
--foreign key reference to product code competitors are binded to products master table. so that user try to avoid deletition from product table without removing any entries from competitor
ALTER TABLE [dbo].[Competitors]  WITH CHECK ADD  CONSTRAINT [FK_CompetitorProduct] FOREIGN KEY([ProductCode])
REFERENCES [dbo].[Products] ([ProductCode])
GO

ALTER TABLE [dbo].[Competitors] CHECK CONSTRAINT [FK_CompetitorProduct]
GO
