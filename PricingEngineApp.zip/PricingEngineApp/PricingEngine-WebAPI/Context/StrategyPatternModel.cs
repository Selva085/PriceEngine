﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace PricingEngine_WebAPI.ContextInterface
{
    /// <summary>
    /// The 'StrategyPatternModel' abstract class
    /// </summary>
  public  abstract class StrategyPatternSum
    {
        public abstract List<KeyValuePair<string, decimal>> sumPrice(List<KeyValuePair<string, decimal>> lstComptPrice);
    }
}