﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PricingEngine_WebAPI.Models;


namespace PricingEngine_WebAPI.ContextInterface
{
    /// <summary>
    /// This 'ConcreteStrategySumCalc' class which implements the abstract class "StrategyPatternSum"
    /// </summary>
    class ConcreteStrategySumCalc : StrategyPatternSum
    {
        public override List<KeyValuePair<string, decimal>> sumPrice(List<KeyValuePair<string, decimal>> lstComptPrice)
        {
            List<KeyValuePair<string, decimal>> grouped = (from kvp in lstComptPrice
                                                           group kvp by kvp.Key
                                                               into g
                                                               select new KeyValuePair<string, decimal>(g.Key, g.Sum(e => e.Value))
                                                       ).ToList();
            return grouped;          
        }
    }
}